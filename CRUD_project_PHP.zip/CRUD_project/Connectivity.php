<?php  
$con=mysqli_connect("localhost","root","","CRUD_project");
if($con)
{
	echo("<h1 style=color:red;>done</h1>");
}
else{
	echo("<h1 style=color:red;>not done</h1>");
	echo(Mysqli_error($con));
}
?>