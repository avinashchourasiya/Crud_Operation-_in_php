<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form method="post" action="">
	<input type="text" name="id" placeholder="Userid to delete" required>
	<input type="submit" name="submit" value="submit">
</form>
<?php
include "Connectivity.php";
if(isset($_POST['submit']))
{
	
	$userid=$_POST["id"];
	$delete="delete from student where userid='$userid'";
	$result=mysqli_query($con,$delete);

		if(mysqli_num_rows($result)>0)
			{
				echo("deleted");
			}

else{
	echo("sero record");
}
}

?>
</body>
</html>