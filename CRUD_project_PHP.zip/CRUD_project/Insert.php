<!DOCTYPE html>
<html>
<body>
	<form method="post" action="">
		<input type="text" name="userid" placeholder="Userid"><br><br>
		<input type="text" name="name" placeholder="Username"><br><br>
		<input type="password" name="pass" placeholder="Password" class="form-control"><br><br>
		<input type="submit" name="submit" value="go">
	</form>
	<?php
		include "Connectivity.php";
		if(isset($_POST['submit']))
		{
			$userid=$_POST['userid'];
			$name=$_POST['name'];
			$pass=$_POST['pass'];
			if(empty($userid) || empty($name) || empty($pass))
			{
				echo("form is empty");
			}
			else{
				$insert="insert into Student values('$userid','$name','$pass')";
				if(mysqli_query($con,$insert))
				{
					echo("data inserted".$name);
				}
				else
				{
				echo("Error Occured");
			}
			
			}
	}


	?>
	</body>
</html>