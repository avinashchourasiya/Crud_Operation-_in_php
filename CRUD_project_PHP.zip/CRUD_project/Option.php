<!DOCTYPE html>
<html>
<body>
	<li><a href="Insert.php">Insert</a></li><br>
	<li><a  href="Select.php">Select</a></li><br>
	<li><a  href="Update.php">Update</a></li><br>
	<li><a  href="Delete.php">Delete</a></li><br>
	</body>
</html>