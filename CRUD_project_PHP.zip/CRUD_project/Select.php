<!DOCTYPE html>
<html>
<body>
	<form method="POST" action="">
		<input type="text" name="name" placeholder="Userid">
		<input type="submit" name="submit" value="check">
	</form>
	<?php
	include "Connectivity.php";
if(isset($_POST['submit']))
{
$name=$_POST['name'];
//echo $name;
if(empty($name))
{
echo("<h2 style=color:pink;>Form is empty</h2>");
}
else
{

$select="select username,password from student where userid='$name'";
if($result=mysqli_query($con,$select))
{
if(mysqli_num_rows($result)>0)
	{
		while($row=mysqli_fetch_array($result))
		{
			echo("<h2 style=color:green;>".$row['username']."&nbsp;&nbsp;".$row['password']."<h2>");
		}
	}
	else{echo("<h1 style=color:red;>no record found</h1>");}
}
}
}
	?>
	</body>
</html>